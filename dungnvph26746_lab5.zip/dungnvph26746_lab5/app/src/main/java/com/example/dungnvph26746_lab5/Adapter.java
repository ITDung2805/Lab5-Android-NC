package com.example.dungnvph26746_lab5;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<Adapter.viewholder>{
    Context context;
    ArrayList<TinTuc> list;

    public Adapter(Context context, ArrayList<TinTuc> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.item_rss,null);
        return new viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewholder holder, int position) {
         TinTuc tinTuc= list.get(position);
         holder.tv_title.setText(tinTuc.getTitle());
        holder.tv_des.setText(tinTuc.getDepersition());
        holder.tv_date.setText(tinTuc.getPubdate());
        holder.tv_link.setText(tinTuc.getLink());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class viewholder extends RecyclerView.ViewHolder{

        TextView tv_title,tv_des,tv_date,tv_link;
        public viewholder(@NonNull View itemView) {
            super(itemView);
            tv_title=itemView.findViewById(R.id.tv_title);
            tv_des=itemView.findViewById(R.id.tv_des);
            tv_date=itemView.findViewById(R.id.tv_date);
            tv_link=itemView.findViewById(R.id.tv_link);

        }
    }
}
