package com.example.dungnvph26746_lab5;

public class TinTuc {
    private String title;
    private String depersition;
    private String pubdate;
    private String link;

    public TinTuc(String title, String depersition, String pubdate, String link) {
        this.title = title;
        this.depersition = depersition;
        this.pubdate = pubdate;
        this.link = link;
    }

    public TinTuc() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDepersition() {
        return depersition;
    }

    public void setDepersition(String depersition) {
        this.depersition = depersition;
    }

    public String getPubdate() {
        return pubdate;
    }

    public void setPubdate(String pubdate) {
        this.pubdate = pubdate;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
